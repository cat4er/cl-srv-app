import sys
from setuptools import setup, find_packages

setup(
    name='chat server',
    version="0.1",
    description="Server package for chat",
    packages=find_packages(),
    author="Victor Pavlyuk",
    author_email="mooncat4er@ya.ru",
    url="https://github.com/cat4er",
)