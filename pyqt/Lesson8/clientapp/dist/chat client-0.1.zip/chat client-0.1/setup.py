from setuptools import setup

setup(
  name='chat client',
  version="0.1",
  description="Server package for chat",
  author="Victor Pavlyuk",
  author_email="mooncat4er@ya.ru",
  url="http://www.blog.pythonlibrary.org",
  packages=["src"]
)